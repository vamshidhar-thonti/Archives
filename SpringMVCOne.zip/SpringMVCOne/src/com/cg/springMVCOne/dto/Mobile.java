package com.cg.springMVCOne.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "mobiledata")
public class Mobile {
	
	@Id
	@Column(name = "mobile_id")
	Integer mobId;
	@Column(name = "mobile_name")
	String mobName;
	@Column(name = "mobile_price")
	Double mobPrice;
	@Column(name = "mobile_category")
	String mobCategory;
	@Column(name = "mobile_online")
	String mobOnline;
	
	public Mobile() {
		// TODO Auto-generated constructor stub
	}
	
	public Mobile(Integer mobId, String mobName, Double mobPrice, String mobCategory, String type) {
		this.mobId = mobId;
		this.mobName  = mobName;
		this.mobPrice = mobPrice;
		this.mobCategory = mobCategory;
		this.mobOnline = type;
	}
	
	
	public String getMobOnline() {
		return mobOnline;
	}

	public void setMobOnline(String mobOnline) {
		this.mobOnline = mobOnline;
	}

	public Integer getMobId() {
		return mobId;
	}
	public void setMobId(Integer mobId) {
		this.mobId = mobId;
	}
	public String getMobName() {
		return mobName;
	}
	public void setMobName(String mobName) {
		this.mobName = mobName;
	}
	public Double getMobPrice() {
		return mobPrice;
	}
	public void setMobPrice(Double mobPrice) {
		this.mobPrice = mobPrice;
	}
	public String getMobCategory() {
		return mobCategory;
	}
	public void setMobCategory(String mobCategory) {
		this.mobCategory = mobCategory;
	}

	@Override
	public String toString() {
		return "Mobile [mobId=" + mobId + ", mobName=" + mobName
				+ ", mobPrice=" + mobPrice + ", mobCategory=" + mobCategory
				+ ", Online=" + mobOnline + "]";
	}
	
}
