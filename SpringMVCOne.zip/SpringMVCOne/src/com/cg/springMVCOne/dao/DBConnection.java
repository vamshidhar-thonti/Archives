package com.cg.springMVCOne.dao;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class DBConnection {
	
	private static Connection con;
	
	public static Connection getDBConnection(){
		FileReader file; 
		try {
			file = new FileReader(new File("oracle.properties"));
			Properties prop = new Properties();
			String url = prop.getProperty("url");
			String userName = prop.getProperty("userName");
			String password = prop.getProperty("password");
			String driver = prop.getProperty("driver");
			
//			Class.forName(driver);
//			DriverManager.re
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return con;
	}

}
