package com.cg.springMVCOne.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.springMVCOne.dto.Mobile;

@Repository("mobiledao")
public class MobileDAOImpl implements MobileDAO {
	
	@PersistenceContext
	EntityManager em;

	@Override
	public void addMobiles(Mobile mobile) {
		// TODO Auto-generated method stub
		em.persist(mobile);
		em.flush();
	}

	@Override
	public List<Mobile> showAllMobiles() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteMobile(int mobid) {
		// TODO Auto-generated method stub

	}

	@Override
	public Mobile searchMobile(int mobid) {
		// TODO Auto-generated method stub
		return null;
	}

}
