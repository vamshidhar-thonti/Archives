package com.cg.mobshop.service;

import java.util.List;

import com.cg.mobshop.dao.PurchaseDAO;
import com.cg.mobshop.dao.PurchaseDAOImpl;
import com.cg.mobshop.dto.Mobile;
import com.cg.mobshop.dto.PurchaseDetails;

public class PurchaseServiceImpl implements PurchaseService {
	
	PurchaseDAO dao;
	
	public PurchaseServiceImpl() {
		// TODO Auto-generated constructor stub
		dao = new PurchaseDAOImpl();
	}

	@Override
	public int addPurchase(PurchaseDetails pd) {
		// TODO Auto-generated method stub
		return dao.addPurchase(pd);
	}

	@Override
	public List<Mobile> getMobileList() {
		// TODO Auto-generated method stub
		return dao.getMobileList();
	}

	@Override
	public List<Mobile> getMobileList(int min, int max) {
		// TODO Auto-generated method stub
		return dao.getMobileList(min, max);
	}

	@Override
	public Mobile updateMobileDetails(Mobile mob) {
		// TODO Auto-generated method stub
		return null;
	}

}
