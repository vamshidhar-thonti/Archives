package com.cg.mobshop.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.mobshop.dto.Mobile;
import com.cg.mobshop.dto.PurchaseDetails;

public interface PurchaseService {
	
	public int addPurchase(PurchaseDetails pd);
	public List<Mobile> getMobileList();
	public List<Mobile> getMobileList(int max, int min);
	public Mobile updateMobileDetails(Mobile mob);
	
}
