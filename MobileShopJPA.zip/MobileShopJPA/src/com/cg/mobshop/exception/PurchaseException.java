package com.cg.mobshop.exception;

public class PurchaseException extends Exception {
	
	public PurchaseException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
