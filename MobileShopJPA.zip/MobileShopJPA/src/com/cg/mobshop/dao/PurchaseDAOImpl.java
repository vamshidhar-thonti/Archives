package com.cg.mobshop.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.mobshop.dto.Mobile;
import com.cg.mobshop.dto.PurchaseDetails;

public class PurchaseDAOImpl implements PurchaseDAO {
	
	EntityManager manager;
	
	public PurchaseDAOImpl() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");
		manager = emf.createEntityManager();
	}

	@Override
	public int addPurchase(PurchaseDetails pd) {
		// TODO Auto-generated method stub
		manager.getTransaction().begin();
		manager.persist(pd);
		manager.getTransaction().commit();
		return pd.getPurchaseId();
	}

	@Override
	public List<Mobile> getMobileList() {
		TypedQuery<Mobile> query = manager.createQuery("select mob from Mobile mob", Mobile.class);
		List<Mobile> list = query.getResultList();
		return list;
	}

	@Override
	public List<Mobile> getMobileList(int max, int min) {
		// TODO Auto-generated method stub
		String qr = "select mob from Mobile mob where price >="+max+" and price <="+min;
		TypedQuery<Mobile> query = manager.createQuery(qr, Mobile.class);
		List<Mobile> list = query.getResultList();
		return list;
	}

	@Override
	public Mobile updateMobileDetails(Mobile mob) {
		// TODO Auto-generated method stub
		return null;
	}
	

}
