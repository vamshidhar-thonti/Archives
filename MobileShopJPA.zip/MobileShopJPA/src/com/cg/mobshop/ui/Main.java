package com.cg.mobshop.ui;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.cg.mobshop.dto.Mobile;
import com.cg.mobshop.dto.PurchaseDetails;
import com.cg.mobshop.service.PurchaseService;
import com.cg.mobshop.service.PurchaseServiceImpl;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		
		int option = 0;
		do{
			System.out.println("1. Add Purchase details...");
			System.out.println("2. Display entire mobile List...");
			System.out.println("3. Display entire mobile List based on the price range...");
			System.out.println("4. Exit...");
			option = sc.nextInt();
			
			switch (option) {
			case 1:
				
				PurchaseDetails pd = new PurchaseDetails();
				PurchaseService ps = new PurchaseServiceImpl();
				System.out.println("Enter Customer name: ");
				String name = sc.next();
				System.out.println("Enter EmailID: ");
				String email = sc.next();
				System.out.println("Enter Mobile Number:");
				String mob = sc.next();
				System.out.println("Enter Mobile ID: ");
				int mobID = sc.nextInt();
				
				pd.setCustName(name);
				pd.setEmail(email);
				pd.setPhoneNo(mob);
				pd.setMobileId(mobID);
				pd.setPurchaseDate(new Date());
				int purchaseID = ps.addPurchase(pd);
				pd.setPurchaseId(purchaseID);
				System.out.println("Record inserted with ID "+ purchaseID);
				System.out.println(pd);
				
				break;
				
			case 2:
				
				List<Mobile> list = new ArrayList<Mobile>();
				PurchaseService ps2 = new PurchaseServiceImpl();
				
				list = ps2.getMobileList();
				for(Mobile m1 : list){
					System.out.println(m1);
				}
				break;
				
			case 3:
				
				List<Mobile> list2 = new ArrayList<Mobile>();
				PurchaseService ps3 = new PurchaseServiceImpl();
				
				System.out.println("Enter minimum price: ");
				int min = sc.nextInt();
				System.out.println("Enter maximum price: ");
				int max = sc.nextInt();
				
				list2 = ps3.getMobileList(min, max);
				for(Mobile m1 : list2){
					System.out.println(m1);
				}
				break;
			
			default:
			case 4:
				break;
			}
		}while(option != 4);
		
		sc.close();
		
	}

}
