package com.cg.mobshop.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
//import javax.persistence.Table;
import javax.persistence.Table;

@Entity
@Table(name = "purchase_details") //Needed only when tableName and class name are different
public class PurchaseDetails {
	
	@Id //Represents the primary key of the attribute where atleast one primary should exist in the table that was created
	@GeneratedValue(strategy = GenerationType.AUTO) //Generates an ID by itself.
	private int purchaseId;//Since the col name in the Db and here are same no need of @Coloumn annotation needed.
	private int mobileId;
	@Column(name = "cname") //Needed only when attritubes in the DB and java class are different.
	private String custName;
	private String email;
	private String phoneNo;
	private Date purchaseDate;
	
	public PurchaseDetails(){
		purchaseDate = new Date();
	}
	
	public int getPurchaseId() {
		return purchaseId;
	}
	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}
	public int getMobileId() {
		return mobileId;
	}
	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public Date getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(Date purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	@Override
	public String toString() {
		return "PurchaseID: " + purchaseId + ", MobileID: "
				+ mobileId + ", CustomerName: " + custName + ", EmailID: " + email
				+ ", PhoneNumber: " + phoneNo + ", PurchaseDate: " + purchaseDate;
	}
	
	
	
}
