package com.wallet.dao;

import java.util.HashMap;
import java.util.Map;

//import com.wallet.dto.Customer;

public class DataContainer {

//	private static Map<String, Customer> maps;
//
//	public static Map<String, Customer> createCollection() {
//
//		if (maps == null)
//			maps = new HashMap<String, Customer>();
//			maps.put("7306451044", new Customer("Vamshi", "7306451044", 500));
//			maps.put("9963357591", new Customer("Sindhu", "9963357591", 1000));
//		return maps;
//	}

}
