package com.cg.purchase.DAO;

import java.util.List;

import com.cg.purchase.dto.Mobile;

public interface MobileDAO {

	public List<Mobile> getAll();
	
}
