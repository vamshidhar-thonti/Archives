package com.cg.purchase.service;

import java.util.List;

import com.cg.purchase.dto.Mobile;

public interface MobileService {
	
	public List<Mobile> getAll();

}
