package pageBean;

public class HotelBookingPageFactory {

}
