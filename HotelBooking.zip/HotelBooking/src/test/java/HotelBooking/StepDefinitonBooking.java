package HotelBooking;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageBean.HotelBookingPageFactory;
import pageBean.HotelLoginPageFactory;

public class StepDefinitonBooking {
	
	private WebDriver driver;
	private HotelBookingPageFactory hbpf;
	
	@Given("^User is logged in successfully and is on Booking page$")
	public void user_is_logged_in_successfully_and_is_on_Booking_page() throws Throwable {
		
		driver = new FirefoxDriver();
		Thread.sleep(1000);
		hbpf = new HotelBookingPageFactory(driver);
		
		driver.get("file:///D:/StudyMaterials/Module%203/hotelBooking/hotelbooking.html");
		
	}

	@Then("^Check the head of the page$")
	public void check_the_head_of_the_page() throws Throwable {
		
		String str = driver.findElement(By.xpath("html/body/div[1]/h2")).getText();
		if(str.contentEquals("Hotel Booking Form"))
			System.out.println("Heading matched...");
		else
			System.out.println("Heading not matched...");
		Thread.sleep(1000);
		driver.close();
		
	}

	@When("^User does not enter a valid or correct name$")
	public void user_does_not_enter_a_valid_or_correct_name() throws Throwable {
		
		hbpf.setFirstName("");
		Thread.sleep(1000);
		
		driver.switchTo().alert().accept();
		
	}

	@Then("^display alert message$")
	public void display_alert_message() throws Throwable {

		hbpf.setBtn();
		System.out.println("******"+driver.switchTo().alert().getText());
		driver.switchTo().alert().accept();
		driver.close();
		
	}

	@When("^User enters valid FirstName$")
	public void user_enters_valid_FirstName() throws Throwable {
		
		hbpf.setFirstName("Vamshi");
		Thread.sleep(1000);
		
	}

	@When("^enters invalid LastName$")
	public void enters_invalid_LastName() throws Throwable {
		
		hbpf.setLastName("");
		Thread.sleep(1000);
		hbpf.setBtn();
		System.out.println("******"+driver.switchTo().alert().getText());
		driver.switchTo().alert().accept();
		driver.close();
		
	}

	@When("^User enters  valid FirstName and LastName$")
	public void user_enters_valid_FirstName_and_LastName() throws Throwable {
		
		hbpf.setFirstName("Vamshi");
		hbpf.setLastName("Nani");
		Thread.sleep(1000);
		hbpf.setBtn();
		System.out.println("******"+driver.switchTo().alert().getText());
		driver.switchTo().alert().accept();
		
	}

	@When("^enters invalid EmailID$")
	public void enters_invalid_EmailID() throws Throwable {
		
		hbpf.setFirstName("Vamshi.com");
		Thread.sleep(1000);
		hbpf.setBtn();
		System.out.println("******"+driver.switchTo().alert().getText());
		driver.switchTo().alert().accept();
		driver.close();
		
	}

	@When("^User enters valid FirstName, LastName and EmailID$")
	public void user_enters_valid_FirstName_LastName_and_EmailID() throws Throwable {
		
		hbpf.setFirstName("Vamshi");
		hbpf.setLastName("Nani");
		hbpf.setEmail("vamshi@vamshi.com");
		Thread.sleep(1000);
		hbpf.setBtn();
		driver.switchTo().alert().accept();
		
	}

	@When("^enters invalid mobile number$")
	public void enters_invalid_mobile_number() throws Throwable {
		
		hbpf.setPhone("54532");
		hbpf.setBtn();
		System.out.println("******"+driver.switchTo().alert().getText());
		driver.switchTo().alert().accept();
		driver.close();
		
	}

//	@When("^enters invalid mobile number$")
//	public void enters_invalid_mobile_number(DataTable arg1) throws Throwable {
//	    // Write code here that turns the phrase above into concrete actions
//	    // For automatic transformation, change DataTable to one of
//	    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
//	    // E,K,V must be a scalar (String, Integer, Date, enum etc)
//	    throw new PendingException();
//	}

	@When("^User enters all valid details till Mobile number$")
	public void user_enters_all_valid_details_till_Mobile_number() throws Throwable {
		
		hbpf.setFirstName("Vamshi");
		hbpf.setLastName("Nani");
		hbpf.setEmail("vamshi@vamshi.com");
		hbpf.setPhone("7894561230");
		hbpf.setBtn();
		System.out.println("******"+driver.switchTo().alert().getText());
		driver.switchTo().alert().accept();
		driver.close();
		
	}

	@When("^leaves address field as blank$")
	public void leaves_address_field_as_blank() throws Throwable {
		
		
	}

	@When("^User does not select a city$")
	public void user_does_not_select_a_city() throws Throwable {
		
		hbpf.setCity("Select City");
		hbpf.setBtn();
		driver.switchTo().alert().accept();
		
	}

	@When("^user enters (\\d+)$")
	public void user_enters(int arg1) throws Throwable {
		
	}

	@Then("^allocate such that (\\d+) room for minimum (\\d+) guests$")
	public void allocate_such_that_room_for_minimum_guests(int arg1, int arg2) throws Throwable {
		
	}

	@When("^user leaves the card holder name blank and clicks the button$")
	public void user_leaves_the_card_holder_name_blank_and_clicks_the_button() throws Throwable {
		
	}

	@When("^user leaves the Debit card number field blank and clicks the button$")
	public void user_leaves_the_Debit_card_number_field_blank_and_clicks_the_button() throws Throwable {
		
	}

	@When("^user leaves the cvv blank and clicks the button$")
	public void user_leaves_the_cvv_blank_and_clicks_the_button() throws Throwable {
		
	}

	@When("^user leaves the expiry month field blank and clicks the button$")
	public void user_leaves_the_expiry_month_field_blank_and_clicks_the_button() throws Throwable {
		
	}

	@When("^user leaves the expiry year field blank and clicks the button$")
	public void user_leaves_the_expiry_year_field_blank_and_clicks_the_button() throws Throwable {
		
	}

	@When("^user does not leave any fields blank and enters valid input format$")
	public void user_does_not_leave_any_fields_blank_and_enters_valid_input_format() throws Throwable {
		
	}

	@Then("^navigate to the Booking confirmed page$")
	public void navigate_to_the_Booking_confirmed_page() throws Throwable {
		
	}

}
