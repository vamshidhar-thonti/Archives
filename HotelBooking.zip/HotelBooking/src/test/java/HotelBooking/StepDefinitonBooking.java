package HotelBooking;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinitonBooking {
	
	@Given("^User is logged in successfully and is on Booking page$")
	public void user_is_logged_in_successfully_and_is_on_Booking_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Check the head of the page$")
	public void check_the_head_of_the_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User does not enter a valid or correct name$")
	public void user_does_not_enter_a_valid_or_correct_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^display alert message$")
	public void display_alert_message() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User enters valid FirstName$")
	public void user_enters_valid_FirstName() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^enters invalid LastName$")
	public void enters_invalid_LastName() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User enters  valid FirstName and LastName$")
	public void user_enters_valid_FirstName_and_LastName() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^enters invalid EmailID$")
	public void enters_invalid_EmailID() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User enters valid FirstName, LastName and EmailID$")
	public void user_enters_valid_FirstName_LastName_and_EmailID() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^enters invalid mobile number$")
	public void enters_invalid_mobile_number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^enters invalid mobile number$")
	public void enters_invalid_mobile_number(DataTable arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    // For automatic transformation, change DataTable to one of
	    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
	    // E,K,V must be a scalar (String, Integer, Date, enum etc)
	    throw new PendingException();
	}

	@When("^User enters all valid details till Mobile number$")
	public void user_enters_all_valid_details_till_Mobile_number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^leaves address field as blank$")
	public void leaves_address_field_as_blank() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User does not select a city$")
	public void user_does_not_select_a_city() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters (\\d+)$")
	public void user_enters(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^allocate such that (\\d+) room for minimum (\\d+) guests$")
	public void allocate_such_that_room_for_minimum_guests(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user leaves the card holder name blank and clicks the button$")
	public void user_leaves_the_card_holder_name_blank_and_clicks_the_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user leaves the Debit card number field blank and clicks the button$")
	public void user_leaves_the_Debit_card_number_field_blank_and_clicks_the_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user leaves the cvv blank and clicks the button$")
	public void user_leaves_the_cvv_blank_and_clicks_the_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user leaves the expiry month field blank and clicks the button$")
	public void user_leaves_the_expiry_month_field_blank_and_clicks_the_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user leaves the expiry year field blank and clicks the button$")
	public void user_leaves_the_expiry_year_field_blank_and_clicks_the_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user does not leave any fields blank and enters valid input format$")
	public void user_does_not_leave_any_fields_blank_and_enters_valid_input_format() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^navigate to the Booking confirmed page$")
	public void navigate_to_the_Booking_confirmed_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

}
