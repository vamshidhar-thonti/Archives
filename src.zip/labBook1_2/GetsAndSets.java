package labBook1_2;

public interface GetsAndSets {
	
	public void setSbuCode(String sbuCode);
	public void setSbuName(String sbuName);
	public void setSbuHead(String sbuHead);
	
	public String getSbuCode();
	public String getSbuName();
	public String getSbuHead();

}
