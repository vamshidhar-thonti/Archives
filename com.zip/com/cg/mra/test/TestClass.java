package com.cg.mra.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.mra.exception.MobileRechargeException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class TestClass {
	
	AccountService as = new AccountServiceImpl();

	@Test
	public void TestOnRechargeAccountMethod() throws MobileRechargeException{
		assertSame(1100, as.rechargeAccount("9010210131", 900));
	}
	
	@Test (expected = MobileRechargeException.class)
	public void TestOnRechargeAccountMethodV2() throws MobileRechargeException{
		as.rechargeAccount("90000000", 123);
		as.rechargeAccount("9632587410", 0);
		as.rechargeAccount("9632587410", -45);
		
	}
	@Test (expected = MobileRechargeException.class)
	public void TestOnRechargeAccountMethodV3() throws MobileRechargeException{
		as.rechargeAccount("@!@", 45);
		as.rechargeAccount("asADsf", -45);
		as.rechargeAccount("", -45);
		as.rechargeAccount(" ", -45);
		as.rechargeAccount("	", -45);
		
		
	}

}
