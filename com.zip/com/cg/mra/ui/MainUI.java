package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.MobileRechargeException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUI {

	public static void main(String[] args) throws MobileRechargeException {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		AccountService service = null;

		int option = 0;

		do {

			System.out.println("1. Account Balance Enquiry");
			System.out.println("2. Recharge Account");
			System.out.println("3. Exit");

			option = sc.nextInt();

			switch (option) {
			case 1:
				
				service = new AccountServiceImpl();
				
				System.out.println("Enter Mobile No: ");
				String mobNo = sc.next();
				if(!service.validateMobNo(mobNo))
					throw new MobileRechargeException("Inavlid Mobile Number");
				
				Account acc = service.getAccountDetails(mobNo);
				
				System.out.println("Your Current Balance is Rs. "+acc.getAccountBalance());

				break;

			case 2:
				
				service = new AccountServiceImpl();
				Account ac = null;
				
				System.out.println("Enter MobileNo: ");
				String mobileNo = sc.next();
				if(!service.validateMobNo(mobileNo))
					throw new MobileRechargeException("Inavlid Mobile Number...");
				System.out.println("Enter Recharge Amount: ");
				double reAmt = sc.nextDouble();
				if(!service.validateAmount(reAmt))
					throw new MobileRechargeException("Invalid amount entered...");
				
				double currBal = service.rechargeAccount(mobileNo, reAmt);
				
				System.out.println("Your Account Recharged Successfully");
				System.out.println("Hello "+ac.getCustomerName()+", Available Balance is "+currBal);

				break;

			default:
			case 3:

				break;
			}

		} while (option != 3);

	}

}
