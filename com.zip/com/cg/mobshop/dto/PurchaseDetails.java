package com.cg.mobshop.dto;

import java.time.LocalDate;

public class PurchaseDetails {
	
	private int purchaseId;
	private int mobileId;
	private String custName;
	private String email;
	private String phoneNo;
	private LocalDate purchaseDate;
	
	public int getPurchaseId() {
		return purchaseId;
	}
	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}
	public int getMobileId() {
		return mobileId;
	}
	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public LocalDate getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(LocalDate purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	@Override
	public String toString() {
		return "PurchaseID: " + purchaseId + ", MobileID: "
				+ mobileId + ", CustomerName: " + custName + ", EmailID: " + email
				+ ", PhoneNumber: " + phoneNo + ", PurchaseDate: " + purchaseDate;
	}
	
	
	
}
