package com.cg.mobshop.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

import com.cg.mobshop.exception.PurchaseException;

public class DBConnection {

	private static Connection con;
	public static Connection getConnection() throws PurchaseException {
		ResourceBundle orc = ResourceBundle.getBundle("oracle");
		String url = orc.getString("url");
		String username = orc.getString("username");
		String password = orc.getString("password");
		String driver = orc.getString("driver");
		try {
			Class.forName(driver);
			System.out.println("Class loaded...");
			con = DriverManager.getConnection(url, username, password);
			System.out.println("Connected to DB...");
		} catch (SQLException e) {
			throw new PurchaseException(e.getMessage());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			throw new PurchaseException(e.getMessage());
		}
		return con;
	}
}
