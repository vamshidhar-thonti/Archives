package com.cg.mobshop.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.mobshop.dto.Mobile;
import com.cg.mobshop.dto.PurchaseDetails;
import com.cg.mobshop.exception.PurchaseException;

public class PurchaseDAOImpl implements PurchaseDAO {

	public Connection con;

	public PurchaseDAOImpl() {
		try {
			con = DBConnection.getConnection();
		} catch (PurchaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public int generateID() {
		int id = 0;
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select pid.nextval from dual");
			if (rs.next()) {
				id = rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return id;
	}

	@Override
	public int addPurchase(PurchaseDetails pd) {
		// TODO Auto-generated method stub
		String sql = "insert into purchaseDetails values(?, ?, ?, ?, sysdate, ?)";
		String decQuantity = "update mobiles set quantity = quantity - 1 where mobileid = ?";
		try {
			PreparedStatement prs = con.prepareStatement(sql);
			PreparedStatement prs2 = con.prepareStatement(decQuantity);
			int id = generateID();
			prs.setInt(1, id);
			prs.setString(2, pd.getCustName());
			prs.setString(3, pd.getEmail());
			prs.setString(4, pd.getPhoneNo());
			prs.setInt(5, pd.getMobileId());
			
//			System.out.println(pd.getMobileId());
			prs2.setInt(1, pd.getMobileId());
			prs2.executeUpdate();

			int rowCount = prs.executeUpdate();
			if (rowCount == 1)
				return id;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public ArrayList<Mobile> getMobileList() {
		// TODO Auto-generated method stub
		ArrayList<Mobile> list = new ArrayList<Mobile>();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from mobiles");
			Mobile m = null;

			while (rs.next()) {
				m = new Mobile(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getString(4));
				list.add(m);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public ArrayList<Mobile> getMobileList(int min, int max) {
		// TODO Auto-generated method stub
		ArrayList<Mobile> list3 = new ArrayList<Mobile>();
		try {
			Statement stmt = con.createStatement();
			String sql = "select * from mobiles where price >= " + min
					+ " and price <= " + max;
			ResultSet rs = stmt.executeQuery(sql);
			Mobile m = null;

			// rs.setInt(1, min);
			// prs.setInt(2, max);

			while (rs.next()) {
				m = new Mobile(rs.getInt(1), rs.getString(2), rs.getInt(3),
						rs.getString(4));
				list3.add(m);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list3;
	}

	@Override
	public Mobile updateMobileDetails(Mobile mob) {
		// TODO Auto-generated method stub
		return null;
	}

}
