package com.cg.mobshop.dao;

import java.util.ArrayList;

import com.cg.mobshop.dto.Mobile;
import com.cg.mobshop.dto.PurchaseDetails;

public interface PurchaseDAO {
	
	public int addPurchase(PurchaseDetails pd);
	public ArrayList<Mobile>getMobileList();
	public ArrayList<Mobile>getMobileList(int max, int min);
	public Mobile updateMobileDetails(Mobile mob);
	
}
